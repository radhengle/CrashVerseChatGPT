# CRASHVERSE touch-input investigation — dev-build-3

## Finding
The uploaded project calls `GameObject.AddComponent<StandaloneInputModule>()` in `Assets/_Project/Scripts/UI/UIFramework.cs`, but the project archive did not include `ProjectSettings/InputManager.asset`. `StandaloneInputModule` relies on legacy input axes such as Horizontal, Vertical, Submit, Cancel, Mouse X, Mouse Y, and Mouse ScrollWheel. Missing axis definitions can cause input-axis errors during EventSystem processing and may prevent pointer/touch processing.

## Change in this diagnostic patch
Added `ProjectSettings/InputManager.asset` with the standard axes used by Unity's legacy StandaloneInputModule. No age-gate business logic or eligibility checks were changed.

## Verification status
This is a source-level corrective candidate, not a confirmed runtime fix. The Unity editor/build toolchain is not available in this environment, so the APK has not been rebuilt or tested on-device. Build this project with the repository's Unity 2022.3.50f1 Android workflow, install the resulting APK, and check whether Month, Year, and Continue respond. If not, capture Unity logcat output to identify any remaining EventSystem/raycast issue.
